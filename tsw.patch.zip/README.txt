Authors: 丁香园主人; ZSun; cfsoso（日语协力）
License: MIT license（见文末）

请将该目录下所有文件解压到，并合并覆盖TSW的安装目录（默认为C:\Program Files (x86)\Tower of the Sorcerer）。详细说明请参见：文本说明文档https://github.com/Z-H-Sun/tswKai/或视频https://www.bilibili.com/video/BV1n341117tw/。

修正了：
* 刷新率过低太卡的问题
* 对话框底色字色衬度低看不清的问题
* 某些字符串搞串出错的问题
* Magician A的蒙版位图错位了一个像素的问题
 
请将下列可执行文件创建（桌面）快捷方式以便启动运行：
* TSW.EN.exe - 英文修正版
* TSW.CN.exe - 普通汉化版
* TSW.JPCN.exe - 日文精译汉化版

注意，英文版及早先的Flash移植版与日语原版的一些台词颇有出入。因此，普通汉化版中的用语译名和对话翻译针对英文原版、日文原版以及Flash移植版的命名方式进行了一定的调和，在准确传达原作者本身的意图之余，也不至于让老玩家产生距离感。而日文精译版在此基础上，更靠近日文原版的台词原义，让玩家能更原汁原味地纯享日文RPG的风味。

为了消除误解，以下列出部分日文精译版的用语和旧译的对照：
门（无定语修饰） = 黄门
钥匙（无定语修饰） = 黄钥匙
紫门 = 蓝门	* 注：原文即为“紫色”
紫钥匙 = 蓝钥匙
闸门 = 机关门（逻辑门）
祭坛 = 商店
蓝/红回复药 = 大/小血瓶
蓝/红水晶 = 蓝/红宝石
神盾 = 神圣盾
神剑·威珀讷『Weaponer』 = 神圣剑
全知神杖·殷忒镠『Intellion』 = 智慧权杖
勇者灵球 = 怪物手册
智慧灵球 = 备忘录
飞翔灵球 = 楼层传送器
万灵药 = 圣水
破坏爆弹 = 炸弹
空间转移秘宝（瞬移之翼） = 中心对称飞行器
升华之翼 = 上楼器
降临之翼 = 下楼器
雪之结晶 = 冰魔法（冰冻徽章）
超级镐 = 地震卷轴
盗贼 = 小偷
蝙蝠 = 小蝙蝠
祭司 = 初级法师
大祭司 = 高级法师
门卫·甲/乙/丙 = 高/中/初级卫兵
骷髅·甲/乙/丙 = 骷髅队长/骷髅士兵/骷髅人
丧尸（骑士） = 兽人（武士）
石怪 = 石头人
史莱姆人 = 幽灵
死灵战士 = 鬼战士
剑士 = 双手剑士
龙 = 魔龙
金骑士 = 骑士队长
黑骑士 = 黑暗骑士
魔术士·甲/乙 = 高/初级巫师
魔导师 = 魔法警卫
大魔导师 = 大法师
魔导师·芝诺 = 魔王Zeno

————————————————————

MIT License

Copyright (c) 2020 CS_CCME (ZHSun)

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
